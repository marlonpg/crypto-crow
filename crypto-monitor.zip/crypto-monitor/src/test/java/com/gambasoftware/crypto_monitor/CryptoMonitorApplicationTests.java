package com.gambasoftware.crypto_monitor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CryptoMonitorApplicationTests {

	@Test
	void contextLoads() {
	}

}
